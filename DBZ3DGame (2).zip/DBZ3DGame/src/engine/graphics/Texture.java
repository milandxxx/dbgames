﻿package engine.graphics;

public class Texture {
    public int id;
    public int width;
    public int height;

    public Texture(int id, int width, int height) {
        this.id = id;
        this.width = width;
        this.height = height;
    }
}
