package com.dbz.game;

import com.dbz.game.engine.GameEngine;

public class Main {
    public static void main(String[] args) {
        new GameEngine().start();
    }
}
