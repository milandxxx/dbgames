package com.dbz.game.engine.audio;

public class AudioEngine {
    public void update() {}
    public void cleanup() {}
}
