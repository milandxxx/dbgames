package com.dbz.game.engine.render;

public class Renderer {
    public void render(Object scene) {
        // Render b�sico
    }

    public void cleanup() {}
}
